package es.iessoterohernandez.daw.endes.fibonacciMain;

import java.util.Scanner;

import es.iessoterohernandez.daw.endes.fibonaci.Fibonacci;

public class FibonacciMain {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
		 
		 int n;
		 System.out.println("Dime el numero para hacer la sucesion: ");
			n = sc.nextInt();
        System.out.println("Fibonacci de " + n + " es: " + Fibonacci.fibonacci(n));
    }
}
